import 'package:flutter/material.dart';

class ScanCar extends StatelessWidget {
  static const String routeName = 'ScanCar';
  const ScanCar({
    super.key,
  });
  void _verifyPlate() {
    // Aquí puedes agregar la lógica para verificar la placa
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Verificación de placa'),
        backgroundColor: Colors.transparent,
        centerTitle: true,
        elevation: 0,
        foregroundColor: Colors.black,
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(0, 0, 0, 30),
              child: Image(
                image: AssetImage('assets/img/dosier.png'),
              ),
            ),
            Text(
              "ESCANER",
              style: TextStyle(
                  fontSize: 31.0,
                  fontWeight: FontWeight.bold,
                  color: Color.fromRGBO(27, 38, 59, 1)),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _verifyPlate,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text('Verificar la placa '),
                  Icon(Icons.camera_alt),
                ],
              ),
              style: ElevatedButton.styleFrom(
                  primary: Color.fromRGBO(
                      65, 90, 119, 1), // Cambia el color de fondo del botón
                  onPrimary: Color.fromRGBO(
                      229, 232, 225, 1), // Cambia el color del texto del botón
                  elevation: 10, // Cambia la elevación del botón
                  padding: EdgeInsets.symmetric(
                      vertical: 15,
                      horizontal: 30), // Cambia el padding del botón
                  shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(30), // Cambia la forma del botón
                  ),
                  minimumSize: Size(160, 50)),
            ),
          ],
        ),
      ),
    );
  }
}
