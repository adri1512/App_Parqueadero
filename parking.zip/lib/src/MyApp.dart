import 'package:flutter/material.dart';
import 'package:parking/src/screens/LogIn.dart';
import 'package:parking/src/screens/LogInAdmin.dart';
import 'package:parking/src/screens/LogInGuard.dart';
import 'package:parking/src/screens/RegisterCar.dart';
import 'package:parking/src/screens/ScanCar.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Hello World',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: 'LogIn',
      routes: {
        LogIn.routeName: (BuildContext context) => const LogIn(),
        LogInAdmin.routeName: (context) => const LogInAdmin(),
        LogInGuard.routeName: (context) => const LogInGuard(),
        RegisterCar.routeName: (context) => const RegisterCar(),
        ScanCar.routeName: (context) => const ScanCar(),
      },
    );
  }
}
