import 'package:flutter/material.dart';
import 'package:parking/src/screens/ScanCar.dart';

class LogInGuard extends StatefulWidget {
  static const String routeName = 'LogInAdmin';
  const LogInGuard({
    super.key,
  });

  @override
  _LogInGuardState createState() => _LogInGuardState();
}

class _LogInGuardState extends State<LogInGuard> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void _login() {
    // Aquí puedes agregar la lógica para verificar las credenciales del usuario
    String username = _usernameController.text;
    String password = _passwordController.text;

    if (username == 'guard' && password == '1234') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const ScanCar(),
        ),
      );
    } else {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text('Credenciales inválidas.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text('Cerrar'),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Login Guardia',
        ),
        backgroundColor: Colors.transparent,
        centerTitle: true,
        elevation: 0,
        foregroundColor: Colors.black,
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "GUARDIA",
              style: TextStyle(
                  fontSize: 31.0,
                  fontWeight: FontWeight.bold,
                  color: Color.fromRGBO(27, 38, 59, 1)),
            ),
            Container(
              width: 300,
              height: 1,
              margin: EdgeInsets.fromLTRB(30, 30, 30, 30),
            ),
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(
                labelText: 'Usuario',
              ),
            ),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Contraseña',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _login,
              child: Text('Iniciar sesión'),
            ),
          ],
        ),
      ),
    );
  }
}
