import 'package:flutter/material.dart';
import 'package:parking/src/MyApp.dart';

void main() => runApp(MyApp());
