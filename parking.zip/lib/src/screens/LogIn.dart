import 'package:flutter/material.dart';
import 'package:parking/src/screens/LogInAdmin.dart';
import 'package:parking/src/screens/LogInGuard.dart';

class LogIn extends StatelessWidget {
  static const String routeName = 'LogIn';
  const LogIn({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(255, 255, 255, 1),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "BIENVENIDOS",
              style: TextStyle(
                  fontSize: 31.0,
                  fontWeight: FontWeight.bold,
                  color: Color.fromRGBO(27, 38, 59, 1)),
            ),
            Text(
              "CAR PARK",
              style: TextStyle(
                  fontSize: 31.0,
                  fontWeight: FontWeight.bold,
                  color: Color.fromRGBO(27, 38, 59, 1)),
            ),
            Container(
              width: 300,
              height: 1,
              margin: EdgeInsets.fromLTRB(30, 30, 30, 30),
            ),
            Container(
              margin: EdgeInsets.fromLTRB(0, 0, 0, 30),
              child: Image(
                image: AssetImage('assets/img/aparcamiento.png'),
              ),
            ),
            Container(
              width: 300,
              height: 1,
              margin: EdgeInsets.fromLTRB(30, 10, 30, 10),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const LogInAdmin(),
                  ),
                );
              },
              child: Text('Administrador'),
              style: ElevatedButton.styleFrom(
                  primary: Color.fromRGBO(
                      65, 90, 119, 1), // Cambia el color de fondo del botón
                  onPrimary: Color.fromRGBO(
                      229, 232, 225, 1), // Cambia el color del texto del botón
                  elevation: 10, // Cambia la elevación del botón
                  padding: EdgeInsets.symmetric(
                      vertical: 15,
                      horizontal: 30), // Cambia el padding del botón
                  shape: RoundedRectangleBorder(
                    borderRadius:
                        BorderRadius.circular(30), // Cambia la forma del botón
                  ),
                  minimumSize: Size(160, 50)),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const LogInGuard(),
                  ),
                );
              },
              child: Text('Guardia'),
              style: ElevatedButton.styleFrom(
                primary: Color.fromRGBO(
                    65, 90, 119, 1), // Cambia el color de fondo del botón
                onPrimary: Color.fromRGBO(
                    229, 232, 225, 1), // Cambia el color del texto del botón
                elevation: 10, // Cambia la elevación del botón
                padding: EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 30), // Cambia el padding del botón
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(30), // Cambia la forma del botón
                ),
                minimumSize: Size(160, 50),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
