import 'package:flutter/material.dart';
import 'package:parking/src/screens/ScanCar.dart';

class LogInGuard extends StatefulWidget {
  static const String routeName = 'LogInAdmin';
  const LogInGuard({
    super.key,
  });

  @override
  _LogInGuardState createState() => _LogInGuardState();
}

class _LogInGuardState extends State<LogInGuard> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void _login() {
    // Aquí puedes agregar la lógica para verificar las credenciales del usuario
    String username = _usernameController.text;
    String password = _passwordController.text;

    if (username == 'guard' && password == '1234') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const ScanCar(),
        ),
      );
    } else {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text('Invalid credentials'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text('Leave'),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          '',
        ),
        backgroundColor: Colors.transparent,
        centerTitle: true,
        elevation: 0,
        foregroundColor: Colors.black,
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              alignment: Alignment.topLeft,
              child: Text(
                "Login account",
                style: TextStyle(
                    fontSize: 35.0,
                    fontWeight: FontWeight.bold,
                    color: Color.fromRGBO(0, 0, 0, 1)),
              ),
            ),
            Container(
              alignment: Alignment.topLeft,
              child: Text(
                "Guard",
                style: TextStyle(
                    fontSize: 40.0,
                    fontWeight: FontWeight.bold,
                    color: Color.fromRGBO(39, 76, 119, 0.8)),
              ),
            ),
            SizedBox(height: 80),
            Container(
              decoration: BoxDecoration(
                color: Color.fromRGBO(139, 140, 137, 0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextField(
                controller: _usernameController,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  prefixIcon: Icon(Icons.person,
                      color: Color.fromRGBO(139, 140, 137, 0.8)),
                  hintText: 'User',
                ),
              ),
            ),
            SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: Color.fromRGBO(139, 140, 137, 0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  hintText: 'Password',
                  prefixIcon: Icon(Icons.vpn_key,
                      color: Color.fromRGBO(139, 140, 137, 0.8)),
                ),
              ),
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: _login,
              child: Text('Sign in'),
              style: ElevatedButton.styleFrom(
                primary: Color.fromRGBO(
                    39, 76, 119, 0.8), // Cambia el color de fondo del botón
                onPrimary: Color.fromRGBO(
                    229, 232, 225, 1), // Cambia el color del texto del botón
                elevation: 10, // Cambia la elevación del botón
                padding: EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 30), // Cambia el padding del botón
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(10), // Cambia la forma del botón
                ),
                minimumSize: Size(340, 50),
              ),
            ),
            SizedBox(height: 5),
            Text(
              'forgot the password',
              style: TextStyle(color: Color.fromRGBO(39, 76, 119, 0.8)),
            ),
            SizedBox(height: 140),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('don´t have an account? '),
                Text(
                  'sing up',
                  style: TextStyle(color: Color.fromRGBO(39, 76, 119, 0.8)),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
