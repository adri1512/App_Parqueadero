import 'package:flutter/material.dart';

class RegisterCar extends StatefulWidget {
  static const String routeName = 'RegisterCar';
  const RegisterCar({
    super.key,
  });

  @override
  _RegisterCarState createState() => _RegisterCarState();
}

class _RegisterCarState extends State<RegisterCar> {
  final TextEditingController _plateController = TextEditingController();
  final TextEditingController _ownerNameController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();
  final TextEditingController _idController = TextEditingController();

  void _registerVehicle() {
    String plate = _plateController.text;
    String ownerName = _ownerNameController.text;
    String phone = _phoneController.text;
    String id = _idController.text;

    // Aquí puedes agregar la lógica para registrar la placa y el nombre del propietario en una base de datos o realizar cualquier otra acción necesaria

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Successful registration'),
          content: Text(
              'Owner name $ownerName and plate $plate have been registered'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Leave'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Car Register'),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.black,
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              child: Image(
                image: AssetImage('assets/img/coche.png'),
              ),
            ),
            SizedBox(height: 10),
            Container(
              alignment: Alignment.topLeft,
              child: Text(
                "Personal Information",
                style: TextStyle(
                    fontSize: 20.0,
                    fontWeight: FontWeight.bold,
                    color: Color.fromRGBO(0, 0, 0, 1)),
              ),
            ),
            SizedBox(height: 15),
            Container(
              decoration: BoxDecoration(
                color: Color.fromRGBO(139, 140, 137, 0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextField(
                controller: _idController,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  prefixIcon: Icon(Icons.widgets_rounded,
                      color: Color.fromRGBO(139, 140, 137, 0.8)),
                  hintText: 'Identification card',
                ),
              ),
            ),
            SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: Color.fromRGBO(139, 140, 137, 0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextField(
                controller: _ownerNameController,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  prefixIcon: Icon(Icons.person_pin_rounded,
                      color: Color.fromRGBO(139, 140, 137, 0.8)),
                  hintText: 'Owner name',
                ),
              ),
            ),
            SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: Color.fromRGBO(139, 140, 137, 0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextField(
                controller: _phoneController,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  prefixIcon: Icon(Icons.phone_rounded,
                      color: Color.fromRGBO(139, 140, 137, 0.8)),
                  hintText: 'Phone',
                ),
              ),
            ),
            SizedBox(height: 10),
            Container(
              decoration: BoxDecoration(
                color: Color.fromRGBO(139, 140, 137, 0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: TextField(
                controller: _plateController,
                cursorColor: Colors.black,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  prefixIcon: Icon(Icons.directions_car,
                      color: Color.fromRGBO(139, 140, 137, 0.8)),
                  hintText: 'Car plate',
                ),
              ),
            ),
            SizedBox(height: 40),
            ElevatedButton(
              onPressed: _registerVehicle,
              child: Text('Register car'),
              style: ElevatedButton.styleFrom(
                primary: Color.fromRGBO(
                    39, 76, 119, 0.8), // Cambia el color de fondo del botón
                onPrimary: Color.fromRGBO(
                    229, 232, 225, 1), // Cambia el color del texto del botón
                elevation: 10, // Cambia la elevación del botón
                padding: EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 30), // Cambia el padding del botón
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(10), // Cambia la forma del botón
                ),
                minimumSize: Size(340, 50),
              ),
            ),
            SizedBox(height: 10),
            OutlinedButton(
              onPressed: _registerVehicle,
              child: Text('Modify register'),
              style: ElevatedButton.styleFrom(
                // Cambia el color de fondo del botón
                onPrimary: Color.fromRGBO(
                    39, 76, 119, 0.8), // Cambia el color del texto del botón
                elevation: 0, // Cambia la elevación del botón
                padding: EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 30), // Cambia el padding del botón
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(10), // Cambia la forma del botón
                ),
                side: const BorderSide(
                  width: 2.0,
                  color: Color.fromRGBO(39, 76, 119, 0.8),
                ),
                minimumSize: Size(340, 50),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
