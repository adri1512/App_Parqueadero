import 'package:flutter/material.dart';

class ScanCar extends StatelessWidget {
  static const String routeName = 'ScanCar';
  const ScanCar({
    super.key,
  });
  void _verifyPlate() {
    // Aquí puedes agregar la lógica para verificar la placa
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(''),
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.black,
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              alignment: Alignment.topLeft,
              child: Text(
                "Verification",
                style: TextStyle(
                    fontSize: 35.0,
                    fontWeight: FontWeight.bold,
                    color: Color.fromRGBO(0, 0, 0, 1)),
              ),
            ),
            Container(
              alignment: Alignment.topLeft,
              child: Text(
                "Car plate",
                style: TextStyle(
                    fontSize: 40.0,
                    fontWeight: FontWeight.bold,
                    color: Color.fromRGBO(39, 76, 119, 0.8)),
              ),
            ),
            SizedBox(height: 20),
            Container(
              height: 380,
              decoration: BoxDecoration(
                color: Color.fromRGBO(139, 140, 137, 0.2),
                borderRadius: BorderRadius.circular(10),
              ),
              child: Padding(
                padding: const EdgeInsets.all(20.0),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.fromLTRB(0, 0, 0, 30),
                      child: Image(
                        image: AssetImage('assets/img/dosier.png'),
                      ),
                    ),
                    Text(
                      "Parking lot",
                      style: TextStyle(
                          fontSize: 31.0,
                          fontWeight: FontWeight.bold,
                          color: Color.fromRGBO(39, 76, 119, 0.8)),
                    ),
                    SizedBox(height: 10),
                    Text(
                      "please scan the plate on the phone to enter",
                      style: TextStyle(
                          fontSize: 20.0,
                          fontWeight: FontWeight.w500,
                          color: Color.fromRGBO(0, 0, 0, 0.8)),
                    ),
                    SizedBox(height: 30),
                    ElevatedButton(
                      onPressed: _verifyPlate,
                      child: Text('Car verification'),
                      style: ElevatedButton.styleFrom(
                        primary: Color.fromRGBO(39, 76, 119,
                            0.8), // Cambia el color de fondo del botón
                        onPrimary: Color.fromRGBO(229, 232, 225,
                            1), // Cambia el color del texto del botón
                        elevation: 10, // Cambia la elevación del botón
                        padding: EdgeInsets.symmetric(
                            vertical: 15,
                            horizontal: 30), // Cambia el padding del botón
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(
                              10), // Cambia la forma del botón
                        ),
                        minimumSize: Size(340, 50),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
