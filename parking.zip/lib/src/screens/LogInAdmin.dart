import 'package:flutter/material.dart';
import 'package:parking/src/screens/RegisterCar.dart';

class LogInAdmin extends StatefulWidget {
  static const String routeName = 'LogInAdmin';
  const LogInAdmin({
    super.key,
  });

  @override
  _LogInAdminState createState() => _LogInAdminState();
}

class _LogInAdminState extends State<LogInAdmin> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  void _login() {
    // Aquí puedes agregar la lógica para verificar las credenciales del usuario
    String username = _usernameController.text;
    String password = _passwordController.text;

    if (username == 'admin' && password == '1234') {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => const RegisterCar(),
        ),
      );
    } else {
      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text('Error'),
            content: Text('Credenciales inválidas.'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: Text('Cerrar'),
              ),
            ],
          );
        },
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Login Administrador',
        ),
        backgroundColor: Colors.transparent,
        centerTitle: true,
        elevation: 0,
        foregroundColor: Colors.black,
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "ADMINISTRADOR",
              style: TextStyle(
                  fontSize: 31.0,
                  fontWeight: FontWeight.bold,
                  color: Color.fromRGBO(27, 38, 59, 1)),
            ),
            Container(
              width: 300,
              height: 1,
              margin: EdgeInsets.fromLTRB(30, 30, 30, 30),
            ),
            TextField(
              controller: _usernameController,
              decoration: InputDecoration(
                labelText: 'Usuario',
              ),
            ),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Contraseña',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _login,
              child: Text('Iniciar sesión'),
            ),
          ],
        ),
      ),
    );
  }
}
