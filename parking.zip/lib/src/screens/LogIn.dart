import 'package:flutter/material.dart';
import 'package:parking/src/screens/LogInAdmin.dart';
import 'package:parking/src/screens/LogInGuard.dart';

class LogIn extends StatelessWidget {
  static const String routeName = 'LogIn';
  const LogIn({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(255, 255, 255, 1),
      body: Column(children: [
        Container(
          width: 300,
          height: 150,
        ),
        Container(
          child: Image(
            image: AssetImage('assets/img/aparcamiento.png'),
          ),
        ),
        Container(
          width: 300,
          height: 50,
        ),
        Container(
          alignment: Alignment.topLeft,
          margin: EdgeInsets.only(left: 60.0),
          child: Text(
            "Welcome to",
            style: TextStyle(
                fontSize: 35.0,
                fontWeight: FontWeight.bold,
                color: Color.fromRGBO(0, 0, 0, 1)),
          ),
        ),
        Container(
          alignment: Alignment.topLeft,
          margin: EdgeInsets.only(left: 120.0),
          child: Text(
            "CarPark",
            style: TextStyle(
                fontSize: 40.0,
                fontWeight: FontWeight.bold,
                color: Color.fromRGBO(39, 76, 119, 1)),
          ),
        ),
        Container(
          width: 300,
          height: 50,
        ),
        ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const LogInAdmin(),
              ),
            );
          },
          child: Text('Administrador'),
          style: ElevatedButton.styleFrom(
              primary: Color.fromRGBO(
                  39, 76, 119, 0.8), // Cambia el color de fondo del botón
              onPrimary: Color.fromRGBO(
                  229, 232, 225, 1), // Cambia el color del texto del botón
              elevation: 10, // Cambia la elevación del botón
              padding: EdgeInsets.symmetric(
                  vertical: 15, horizontal: 30), // Cambia el padding del botón
              shape: RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(10), // Cambia la forma del botón
              ),
              minimumSize: Size(340, 50)),
        ),
        SizedBox(height: 20),
        ElevatedButton(
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const LogInGuard(),
              ),
            );
          },
          child: Text('Guardia'),
          style: ElevatedButton.styleFrom(
            primary: Color.fromRGBO(
                39, 76, 119, 0.8), // Cambia el color de fondo del botón
            onPrimary: Color.fromRGBO(
                229, 232, 225, 1), // Cambia el color del texto del botón
            elevation: 10, // Cambia la elevación del botón
            padding: EdgeInsets.symmetric(
                vertical: 15, horizontal: 30), // Cambia el padding del botón
            shape: RoundedRectangleBorder(
              borderRadius:
                  BorderRadius.circular(10), // Cambia la forma del botón
            ),
            minimumSize: Size(340, 50),
          ),
        ),
      ]),
    );
  }
}
