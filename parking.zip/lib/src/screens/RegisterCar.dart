import 'package:flutter/material.dart';

class RegisterCar extends StatefulWidget {
  static const String routeName = 'RegisterCar';
  const RegisterCar({
    super.key,
  });

  @override
  _RegisterCarState createState() => _RegisterCarState();
}

class _RegisterCarState extends State<RegisterCar> {
  final TextEditingController _plateController = TextEditingController();
  final TextEditingController _ownerNameController = TextEditingController();

  void _registerVehicle() {
    String plate = _plateController.text;
    String ownerName = _ownerNameController.text;

    // Aquí puedes agregar la lógica para registrar la placa y el nombre del propietario en una base de datos o realizar cualquier otra acción necesaria

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Registro exitoso'),
          content: Text(
              'La placa $plate y el nombre del propietario $ownerName han sido registrados.'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('Cerrar'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Registro de vehículo'),
        backgroundColor: Colors.transparent,
        centerTitle: true,
        elevation: 0,
        foregroundColor: Colors.black,
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          children: [
            Container(
              margin: EdgeInsets.fromLTRB(0, 0, 0, 30),
              child: Image(
                image: AssetImage('assets/img/coche.png'),
              ),
            ),
            TextField(
              controller: _plateController,
              decoration: InputDecoration(
                labelText: 'Placa',
              ),
            ),
            TextField(
              controller: _ownerNameController,
              decoration: InputDecoration(
                labelText: 'Nombre del propietario',
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _registerVehicle,
              child: Text('Registrar'),
            ),
          ],
        ),
      ),
    );
  }
}
